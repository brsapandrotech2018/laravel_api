<?php

namespace Database\Factories;

use App\Models\UserTypeMaster;
use Illuminate\Database\Eloquent\Factories\Factory;

class UserTypeMasterFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = UserTypeMaster::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
            'user_type' => $this->faker->text(10),
            'description' => $this->faker->text(100),
            
        ];
    }
}
