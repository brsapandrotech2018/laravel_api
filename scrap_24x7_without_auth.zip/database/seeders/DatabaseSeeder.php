<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory(10)->create();

        // \App\Models\Category::factory(20)->create();

        // \App\Models\Unit::factory(20)->create();

        // \App\Models\CategoryItem::factory(20)->create();

        // \App\Models\Customer::factory(15)->create();

        // \App\Models\CustomerAdd::factory(20)->create();

        // \App\Models\UserMaster::factory(20)->create();

        // \App\Models\UserTypeMaster::factory(10)->create();
    }
}
